const SQUADR_TEAL   = '#1A3636';
const SQUADR_ORANGE = '#F95738';

function SplashScreen({ exiting = false }) {
  return (
    <div
      className={`splash${exiting ? ' splash--exit' : ''}`}
      role="presentation"
      aria-hidden="true"
    >
      <div className="splash__content">
        <svg
          className="splash__mark"
          viewBox="0 0 26 24"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
          shapeRendering="geometricPrecision"
        >
          <circle className="splash__dot splash__dot--1" cx="13" cy="6"  r="5" fill={SQUADR_ORANGE} />
          <circle className="splash__dot splash__dot--2" cx="6"  cy="17" r="5" fill={SQUADR_TEAL} />
          <circle className="splash__dot splash__dot--3" cx="20" cy="17" r="5" fill={SQUADR_TEAL} />
        </svg>
        <span className="splash__text" style={{ color: SQUADR_TEAL }}>
          SQUADR
        </span>
      </div>
    </div>
  );
}

export default SplashScreen;
